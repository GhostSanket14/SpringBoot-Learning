package com.SanketFirstRestApp.RestfulWebServices01.user;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class post {

	@Id
	@GeneratedValue
	private Integer id;

	private String description;

	public post(Integer id, String description) {
		super();
		this.id = id;
		this.description = description;
	}
	
	
	// We don't want user to be part of 'post' JSON. So we ignore it.
	@ManyToOne(fetch = FetchType.LAZY) // default is Eager, Eager retrive's details of post and user in same query.
	@JsonIgnore							 // Lazy will wont fetch the user details.	
	private user UserObj; // This is what i will map into the @OneTOMany

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "post [id=" + id + ", description=" + description + "]";
	}

	public user getUserObj() {
		return UserObj;
	}

	public void setUserObj(user userObj) {
		UserObj = userObj;
	}	
}