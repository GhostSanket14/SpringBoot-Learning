package com.SanketFirstRestApp.RestfulWebServices01.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SanketFirstRestApp.RestfulWebServices01.user.user;

public interface userRepository extends JpaRepository<user, Integer>{
	
}