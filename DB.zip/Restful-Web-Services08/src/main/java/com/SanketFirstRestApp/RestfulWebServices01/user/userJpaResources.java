package com.SanketFirstRestApp.RestfulWebServices01.user;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.SanketFirstRestApp.RestfulWebServices01.jpa.postRepository;
import com.SanketFirstRestApp.RestfulWebServices01.jpa.userRepository;

import jakarta.validation.Valid;

@RestController
public class userJpaResources {
	// For JPA we changed the url, to remove errors, as userResource also have same url's.
	
	private userDAO userDaoObj;
	private userRepository userRepoObj;  // We will slowly replace the DAo with Repo
	private postRepository postRepoObj;
	
	public userJpaResources(postRepository postRepoObj, userRepository userRepoObj) {
		super();
		this.postRepoObj=postRepoObj;
		this.userRepoObj=userRepoObj;
	}

	@GetMapping("/jpa/users")
	public List<user> findAllUsers(){ 
		return userRepoObj.findAll(); // used jpa Func here.
	}
	@GetMapping("/jpa/users/{id}")
	public EntityModel<user> findOneUsers(@PathVariable int id){ 
		Optional<user> oneUser= userRepoObj.findById(id); // used jpa Func here and below.
	
		if(oneUser.isEmpty()) {
			throw new UserNotFoundException("The user with id:"+id+" dont exist ");
		}
		EntityModel<user> emO=EntityModel.of(oneUser.get());
		
		WebMvcLinkBuilder link=linkTo(methodOn(this.getClass()).findAllUsers());
		emO.add(link.withRel("All-users"));
		
		return emO;
	}
	
	@PostMapping("/jpa/users")
	public ResponseEntity<user> CreateUser(@Valid @RequestBody user userObj){  
		user userForRequest=userRepoObj.save(userObj); // make sue to send POST request
		URI location=ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(userForRequest.getId()).toUri();
		return ResponseEntity.created(location).build();
	}
	
	@DeleteMapping("/jpa/users/{id}")
	public void DeleteOneUsers(@PathVariable int id){
		userRepoObj.deleteById(id);
	}
	
	@GetMapping("/jpa/users/{id}/posts")   // Here we will rretive  
	public List<post> RetrivePostOfOneUsers(@PathVariable int id){
		Optional<user> oneUser= userRepoObj.findById(id); // used jpa Func here and below.
		
		if(oneUser.isEmpty()) {
			throw new UserNotFoundException("The user with id:"+id+" dont exist ");
		}
		
		return oneUser.get().getPostObj();
	}
	
	@PostMapping("/jpa/users/{id}/posts")   // Here we will rretive  
	public ResponseEntity<Object> CreatePostOfOneUsers(@PathVariable int id, @Valid @RequestBody post postObj ){
		Optional<user> oneUser= userRepoObj.findById(id); // used jpa Func here and below.
		
		if(oneUser.isEmpty()) {
			throw new UserNotFoundException("The user with id:"+id+" dont exist ");
		}
		
		postObj.setUserObj(oneUser.get());
		post savedPost=postRepoObj.save(postObj);
		
		URI location=ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(savedPost.getId()).toUri();
		return ResponseEntity.created(location).build();
	}
	
}