package com.SanketFirstRestApp.RestfulWebServices01.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SanketFirstRestApp.RestfulWebServices01.user.post;
import com.SanketFirstRestApp.RestfulWebServices01.user.user;

public interface postRepository extends JpaRepository<post, Integer>{
	
}