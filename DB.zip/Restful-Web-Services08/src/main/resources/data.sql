insert into User_Details(id, name, birthdate)
values(2001, 'Sanket', current_date());
insert into User_Details(id, name, birthdate)
values(2002, 'Banket', current_date());
insert into User_Details(id, name, birthdate)
values(2003, 'Canket', current_date());

insert into post(id, user_obj_id, description)
values(1, 2003, 'AG');
insert into post(id, user_obj_id, description)
values(2, 2002, 'BG');
insert into post(id, user_obj_id, description)
values(3, 2001, 'CG');